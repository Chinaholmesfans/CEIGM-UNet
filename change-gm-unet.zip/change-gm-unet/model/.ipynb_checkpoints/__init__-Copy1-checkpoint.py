from __future__ import annotations
import torch
from torch import Tensor
from torch import nn
from typing import Any
# from model.encoder import Encoder
from model.encoder import Encoder2
# from model.encoder import Encoder4
# from model.encoder import Encoder3
# from model.encoder import Encoder5
# from model.encoder import Encoder6
# from model.decoder import Decoder
# from model.emdecoder import EMCAD as EMCAD0
# from model.emdecoder2 import EMCAD
# from model.emdecoder3 import EMCAD
# from model.emdecoder4 import EMCAD
# from model.emdecoder6 import EMCAD
# from model.emdecoder7 import EMCAD
# from model.emdecoder8 import EMCAD
# from model.emdecoder9 import EMCAD
# from model.emdecoder10 import EMCAD
# from model.emdecoder11 import EMCAD as EMCAD1
# from model.emdecoder12 import EMCAD
# from model.emdecoder122 import EMCAD as EMCAD2
from model.emdecoder1222 import EMCAD as EMCAD22
from model.emdecoder1222n import EMCAD as EMCAD22n
from model.emdecoder1222n3 import EMCAD as EMCAD22n3
# from model.emdecoder1222n2 import EMCAD as EMCAD22n2
# from model.emdecoder1222_2 import EMCAD as EMCAD22_2
# from model.emdecoder12222 import EMCAD as EMCAD23
# from model.emdecoder1223 import EMCAD as EMCAD23
# from model.emdecoder123 import EMCAD as EMCAD3
# from model.networks import EMCADNet
from model.emdecoderLGAG import EMCAD as EMCADLGAG
from model.emdecoderdyupp import EMCAD as EMCADdyupp

class MSVMUNet(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 9,
        *,
        enc_name: str = "gm_tiny"  # tiny_0230s, small_0229s
    ) -> None:
        super(MSVMUNet, self).__init__()
        # self.encoder = Encoder(enc_name, in_channels=in_channels)
        self.encoder = Encoder2("gm_tiny",in_channels=in_channels)
        # self.encoder = Encoder3("sm_tiny",in_channels=in_channels)
        # self.encoder = Encoder4("mlla_tiny",in_channels=in_channels)
        # self.encoder = Encoder5("evm_tiny",in_channels=in_channels)
        # self.encoder = Encoder6("ev_tiny",in_channels=in_channels)
        # self.encoder = EMCADNet(in_channels=in_channels)
        self.dims = self.encoder.dims
        # self.decoder = Decoder(dims=self.dims[::-1], num_classes=num_classes)
        if self.dims[0] == 96 or self.dims[0] == 64:
            self.dims = self.dims[::-1]
        
        self.decoder = EMCAD22n(channels=self.dims,num_classes=num_classes)
        # self.decoder = EMCAD22_2(channels=self.dims,num_classes=num_classes)
        # self.decoder = EMCAD(channels=self.dims[::-1],num_classes=num_classes)

        print('Model %s created, param count: %d' %
                     ('current decoder: ', sum([m.numel() for m in self.decoder.parameters()])))

    def forward(self, x: Tensor) -> Tensor | tuple[Tensor]:
        # print(x.shape)
        if x.shape[1] == 1:
            x = x.repeat(1, 3, 1, 1)
        return self.decoder(self.encoder(x)[::-1])

    def save(self, save_mode_path) -> None:
        torch.save(self.state_dict(), save_mode_path)
        

    @torch.no_grad()
    def freeze_encoder(self) -> None:
        self.encoder.freeze_params()

    @torch.no_grad()
    def unfreeze_encoder(self) -> None:
        self.encoder.unfreeze_params()


class MSVMUNet2(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 9,
        *,
        enc_name: str = "gm_tiny"  # tiny_0230s, small_0229s
    ) -> None:
        super(MSVMUNet2, self).__init__()
        self.encoder = Encoder6("ev_tiny",in_channels=in_channels)
        self.dims = self.encoder.dims
        for i in range(len(self.dims)):
            self.dims[i] = self.dims[i] // 16
        self.dims = self.dims[::-1]

        self.decoders = nn.ModuleList()
        for i in range(16):
            self.decoders.append(EMCAD22_2(channels=self.dims,num_classes=num_classes))

    def forward(self, x: Tensor) -> Tensor | tuple[Tensor]:
        # print(x.shape)
        if x.shape[1] == 1:
            x = x.repeat(1, 3, 1, 1)
        x = self.encoder(x)[::-1]
        xs = []
        xss = []
        os = []
        for each in x:
            xs.append(torch.chunk(each,16,dim = 1))
        for i in range(16):
            xss.append([xs[0][i],xs[1][i],xs[2][i]])
            
        for i in range(16):
            os.append(self.decoders[i](xss[i]))

        combined_tensor = torch.cat([
    torch.cat(os[i*4:(i+1)*4], dim=3) for i in range(4)
], dim=2)
        
        return combined_tensor

    @torch.no_grad()
    def freeze_encoder(self) -> None:
        self.encoder.freeze_params()

    @torch.no_grad()
    def unfreeze_encoder(self) -> None:
        self.encoder.unfreeze_params()


class MSVMUNet3(nn.Module):
    def __init__(
        self,
        in_channels: int = 3,
        num_classes: int = 9,
        *,
        enc_name: str = "gm_tiny"  # tiny_0230s, small_0229s
    ) -> None:
        super(MSVMUNet3, self).__init__()

    def forward(self, x: Tensor) -> Tensor | tuple[Tensor]:
        return x

    @torch.no_grad()
    def freeze_encoder(self) -> None:
        self.encoder.freeze_params()

    @torch.no_grad()
    def unfreeze_encoder(self) -> None:
        self.encoder.unfreeze_params() 



def build_model(**kwargs: Any) -> MSVMUNet:
    return MSVMUNet(**kwargs)
