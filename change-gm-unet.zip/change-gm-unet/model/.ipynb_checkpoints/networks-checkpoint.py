import torch
import torch.nn as nn
import torch.nn.functional as F

from model.pvtv2 import pvt_v2_b0, pvt_v2_b1, pvt_v2_b2, pvt_v2_b3, pvt_v2_b4, pvt_v2_b5


class EMCADNet(nn.Module):
    def __init__(self, in_channels, num_classes=1, kernel_sizes=[1,3,5], expansion_factor=2, dw_parallel=True, add=True, lgag_ks=3, activation='relu', encoder='pvt_v2_b2', pretrain=True, choose=0):
        super(EMCADNet, self).__init__()
        self.in_channels = in_channels
        self.num_classes = num_classes
        self.encoder = encoder

        # conv block to convert single channel to 3 channels
        self.conv = nn.Sequential(
            nn.Conv2d(1, 3, kernel_size=1),
            nn.BatchNorm2d(3),
            nn.ReLU(inplace=True)
        )
        
        self.backbone = pvt_v2_b2()  
        path = './pretrained_pth/pvt/pvt_v2_b2.pth'
        channels=[512, 320, 128, 64]
        self.dims = channels
            
        if pretrain==True:
            print("load!")
            save_model = torch.load(path)
            model_dict = self.backbone.state_dict()
            state_dict = {k: v for k, v in save_model.items() if k in model_dict.keys()}
            model_dict.update(state_dict)
            self.backbone.load_state_dict(model_dict)
        
        print('Model %s created, param count: %d' %
                     (encoder+' backbone: ', sum([m.numel() for m in self.backbone.parameters()])))
        
        #   decoder initialization
    
    def get_params(self):
        return [ sum([m.numel() for m in self.backbone.parameters()]),sum([m.numel() for m in self.decoder.parameters()])]
        
    def forward(self, x, mode='test'):
        
        # if grayscale input, convert to 3 channels
        """
        if x.size()[1] == 1 and self.encoder != "mamba":
            x = self.conv(x)
        """
        
        # encoder
        x1, x2, x3, x4 = self.backbone(x)

        return [x1, x2, x3, x4]

    @torch.no_grad()
    def freeze_params(self) -> None:
        for name, param in self.named_parameters():
            param.requires_grad = False

    @torch.no_grad()
    def unfreeze_params(self) -> None:
        for name, param in self.named_parameters():
            param.requires_grad = True
               

        
if __name__ == '__main__':
    model = EMCADNet().cuda()
    input_tensor = torch.randn(1, 3, 256, 256).cuda()

    P = model(input_tensor)
    print(P[0].size(), P[1].size(), P[2].size(), P[3].size())

